function setup() {
  createCanvas(600, 600);
  

}

function draw() {
  background(100,200,300);
  rect(197, 200, 200, 125, 20);
  rect(375, 400, 200, 125, 20);
  rect(20, 400, 200, 125, 20);
 
  
   text("Welcome to the game center", 130, 115) 
  
  let t = 'Conversation Simulator';
  textSize(25)
  text( t, 225, 235, 70 )
  
  let o = 'Writing Game'
  textSize(25)
  text (o, 75, 435, 70);
  
  let p = 'Shape Match'
  textSize(25)
  text (p, 437, 435, 70)
  
  rect(0,0,600,40)
  textSize(24)
  text('username',450,27)
  circle(425,20,30);
  
  convosimulator = createButton("Conversation Simulator");
  convosimulator.position(225,295);
  convosimulator.mousePressed(ConvoSim);
    
  
  writinggame = createButton("Writing Game");
  writinggame.position(75, 495);
  writinggame.mousePressed(WritingGame);
  
  shapematch = createButton("Shape Match");
  shapematch.position(437, 495);
  shapematch.mousePressed(ShapeMatch);
  
  
  function ConvoSim(){
    window.open('https://editor.p5js.org/PragyaKumari2/sketches/s94bDHSnn');  
  }
  function WritingGame(){
    window.open('https://editor.p5js.org/hparagon/sketches/aHpNfXNLR');
  }
  function ShapeMatch(){
    window.open('https://editor.p5js.org/lhgonza1/sketches/ONkvho0bX ');
  }

 
  
 

}